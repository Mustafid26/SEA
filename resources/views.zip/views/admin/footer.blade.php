<footer class="footer">
    <div class="d-sm-flex justify-content-center justify-content-sm-between">
        <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright © <a
                href="https://instagram.com/ppko_hmtiudinus">
                Serat Kartini Education Academy
            </a> All rights reserved.
        </span>
    </div>
</footer>